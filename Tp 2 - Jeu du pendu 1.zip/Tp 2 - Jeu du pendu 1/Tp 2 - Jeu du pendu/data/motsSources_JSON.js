"use strict"


let motsSources = {
    "mot_1": "cheval",
    "mot_2": "hydravion",
    "mot_3": "funiculaire",
    "mot_4": "trotinette",
    "mot_5": "brocoli",
    "mot_6": "grenade",
    "mot_7": "pyramide",
    "mot_8": "courrier",
    "mot_9": "cadavre",
    "mot_10": "xylophone",
    "mot_11": "asphalte",
    "mot_12": "canneberge",
    "mot_13": "cuivre",
    "mot_14": "scorpion",
    "mot_15": "cognac",
    "mot_16": "anticonstitusionnellement"
}