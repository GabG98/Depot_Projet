
    const PATH_OUVERT = 'images/personnage_1.jpg';
    const PATH_FERMER = 'images/personnage_2.jpg';

    function starteur() {
        fermer();
        setTimeout(viderDialogue, 1500);
    }

    function ouvrire() {
        $('#personnage').attr('src', PATH_FERMER);
        setTimeout(fermer, 100)
    }

    function fermer() {
        $('#personnage').attr('src', PATH_OUVERT);
        setTimeout(ouvrire, 1500)
    }
    function viderDialogue() {
    $('#dialogues').attr('src', 'images/phylactere_rien.jpg');
    }
    function defeat(){
        $('#dialogues').attr('src', 'images/phylactere_desole.jpg');
        setTimeout(viderDialogue, 1500);
    }
    function victory(){
        $('#dialogues').attr('src', 'images/phylactere_bravo.jpg');
        setTimeout(viderDialogue, 1500);
    }
    function mauvaisLettre() {
        $('#dialogues').attr('src', 'images/phylactere_zut.jpg');
        setTimeout(viderDialogue, 1500);
    }
    function bonneLettre() {
        $('#dialogues').attr('src', 'images/phylactere_super.jpg');
        setTimeout(viderDialogue, 1500);
    }