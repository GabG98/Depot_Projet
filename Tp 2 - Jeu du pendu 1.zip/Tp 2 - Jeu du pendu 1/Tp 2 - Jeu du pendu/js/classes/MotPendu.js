"use strict"

let tabNombreCourrant = [];
let nbrMauvaiseLettre = 0;
let nbrBonneLettre = 0;
let mots = choisirMot();

function verifierLettre(lettre) {
    let tabLettre = [];
    for (let i = 0; i < mots.length; i++) {
        if (mots[i] === lettre) {
            tabLettre.push(i);
            console.log("index" + i);
             nbrBonneLettre++;
        }
    }
    if (tabLettre.length <= 0) {
        nbrMauvaiseLettre++;
    }
    return tabLettre;
}

function longueurMot() {
    return mots.length
}

function motCompleter() {
     return nbrBonneLettre == longueurMot();
}

function lettreNONValide() {
       return nbrMauvaiseLettre;
}
 function  reinitialiserValeur() {
     nbrBonneLettre = 0;
     nbrMauvaiseLettre = 0;
     mots=choisirMot();
 }
class MotPendu {
    constructor(tabMot) {
        this._mot = tabMot;
        this.reinitialiserValeur();
    }



   get longueurMot() {
        return this._mot.length
    }

    verifierLettre(lettre) {
        let tabLettre = [];
        for (let i = 0; i < this._mot.length; i++) {
            if (this._mot[i] === lettre) {
                tabLettre.push(i);
                this._nbrBonneLettre++;
            }
        }
        if (tabLettre.length <= 0){
            this._nbrMauvaiseLettre++;
        }
        return tabLettre;
    }

    motCompleter() {
        return this._nbrBonneLettre === this.longueurMot;
    }

    get lettreNONValide() {
          return this._nbrMauvaiseLettre;
    }

    reinitialiserValeur() {
        this._nbrBonneLettre = 0;
        this._nbrMauvaiseLettre = 0;
    }

        get mot() {
        return this._mot;
    }
}


