"use strict"

//TODO : ajouter restriction de  longueur de mot entre 3 et 12
function remplirTabMot(tabJSON) {
    let tabMots = [];

    for (const cle in tabJSON) {
        if (tabJSON[cle].length >= 3 && tabJSON[cle].length <= 12){
            tabMots.push(tabJSON[cle]);
            console.log(tabMots);
        }

    }
    //TRACE
    //console.log(tabMots);
    return (tabMots.length == 0) ? null : tabMots;
}


function choisirMot() {
    let tabMot = remplirTabMot(motsSources);
    let mot = "";
    console.log(tabMot)
    //algo pour choisir un mot pour le jeu
    let nombreCourant = 0;
    nombreCourant = Math.floor((Math.random() * (tabMot.length - 1) + 1))
    console.log("Voici le nombre obtenu: " + nombreCourant)
    //console.log("voici le mot: " + tabMot[nombreCourant]._mot)
    mot = tabMot[nombreCourant];
    console.log(mot);
    //console.log("longueur du mot :" + mot.longueurMot())
    //console.log(tabMot)
    deplacerMotChoisit(tabMot, nombreCourant);

    return mot
}

function deplacerMotChoisit(tabMot, indice) {
    let motAjouterEnPremier = tabMot[indice]
    tabMot.splice(indice, 1);
    tabMot.unshift(motAjouterEnPremier);
    console.log("Objet a ajouter : " + motAjouterEnPremier);
    console.log("Voici le nouvel ordre!")
    console.log(tabMot)

}
// function main() {
//     choisirMot();
// }
//
// main();
