let premierTemps = null;
let min = 0;
let sec = 0;


let motsEsseyer = 0;
let motsReussi = 0;
let pointAccumuler = 0;

function chrono() {
    let temps = [];

    if (premierTemps == null) {
        premierTemps = new Date().getTime();
    }
    let tempsActuel = new Date().getTime();
    let tempsPasser = tempsActuel - premierTemps;


    min = Math.floor(tempsPasser / 60000);
    sec = Math.floor((tempsPasser % 60000) / 1000);


    return temps;
}

function accord(nb) {
    let arccorder = ''
    if (nb > 1) {
        arccorder = 's'
    }

    return arccorder;

}


function nbMotsEsseyer() {
    return motsEsseyer;
}

function nbMotsReussi() {
    return motsReussi;
}

function nbPointAccumuler() {
    pointAccumuler += mots.length-nbrMauvaiseLettre;
    return pointAccumuler;
}