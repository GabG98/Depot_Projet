$(document).ready(function () {

    const VALEUR_ASKI_A = 97;
    const VALEUR_ASKI_Z = 122;

    creerBone();

    function creerBone() {

        $('body').append(createHtmlElement('fieldset', 'fieldset'));


        $('#fieldset').append(createHtmlElement('table', 'cadrage').attr({
            // width: '675',
            border: '0',
            cellspacing: '0',
            cellpadding: '0'
        }));


        $('#cadrage').append(createHtmlElement('tr', 'boxTitre').append(createHtmlElement('td', 'titre').attr({
            colspan: '2',
            align: 'left',
            valign: 'top'
        })));


        $('#cadrage').append(createHtmlElement('tr', 'consequenceBox').append(createHtmlElement('td', 'prendu').attr({
            rowspan: '2',
            align: 'left',
            valign: 'top'
        })).append(createHtmlElement('td', 'dialogue').attr({
            align: 'left',
            valign: 'top'
        })));


        $('#cadrage').append(createHtmlElement('tr', 'personnageBox').append(createHtmlElement('td', 'corp').attr({
            align: 'left',
            valign: 'top'
        })));


        $('#fieldset').append(createHtmlElement('div', 'mot_cache'));


        $('#fieldset').append(createHtmlElement('div', 'clavier'));

        $('#fieldset').append(createHtmlElement('div', 'scoreBoard'));
        $('#scoreBoard').append(createHtmlElement('p', 'score'));
        $('#scoreBoard').append(createHtmlElement('p', 'infoScore'));


        ajouterContenu();
    }

    function ajouterContenu() {


        $('#titre').append(createImage('jeuB', 'images/titre.jpg', '675', '92', 'Jeu du bonhomme pendu'));

        $('#prendu').append(createImage('dessin', 'images/bonhomme_pendu_0.jpg', '400', '433', 'dessin'));

        $('#dialogue').append(createImage('dialogues', 'images/phylactere_intro.jpg', '275', '192', 'dialogue'));

        $('#corp').append(createImage('personnage', 'images/personnage_1.jpg', '275', '241', 'personnage'));

        $('#score').text(`Point possible : 9 / 9`);

        $('#infoScore').text(`Vous avez pris 0 minute et 0 seconde pour decouvrir 0 mots sur 0 essai , ce qui vous a donné 0 point `);

        askiAffichage();

        createUnderScore()

        starteur();

        chronos();
    }

    function newGamePlus() {
        //$('#jeuB').attr('src', 'images/titre.jpg');

        $('#dessin').attr('src', 'images/bonhomme_pendu_0.jpg');

        $('#dialogues').attr('src', 'images/phylactere_intro.jpg');

       // $('#personnage').attr('src', 'images/personnage_1.jpg');

        $('#mot_cache').empty();
        createUnderScore();

        $('#clavier').empty();
        askiAffichage();

        starteur();
        chronos();
    }

    function askiAffichage() {

        const DEFAULT_DIV = '<div></div>';

        for (let i = VALEUR_ASKI_A; i <= VALEUR_ASKI_Z; i++) {
            let lettre = String.fromCharCode(i);
            let divCreate = $(DEFAULT_DIV).text(lettre.toUpperCase());
            divCreate.attr('id', lettre)
            divCreate.attr('class', `lettreClavier`)
            divCreate.on('click', () => {
                switche(verifierLettre(lettre), lettre);
                divCreate.attr('class', 'lettreNommer');
                $('.lettreNommer').off('click');
            });
            $('#clavier').append(divCreate);
        }


    }

    function chronos() {
        $('.lettreClavier').on('click', () => {
            chrono();
            $('#infoScore').text(`Vous avez pris ${min} minute${accord(min)} et ${sec} seconde${accord(sec)} pour decouvrir 0 mots sur 0 essai , ce qui vous a donné ${pointAccumuler} point `);
        });
    }


    function createUnderScore() {

        for (let i = 0; i < longueurMot(); i++) {
            $('#mot_cache').append(createImage(`underScore_index_${i}`, 'images/lettres_mot/underscore.gif', '', '', 'UnderScore').attr('class', 'underS'));
        }

    }

    function switche(index, lettre) {
       // let victoire = true;
        if (!Array.isArray(index) || index.length <= 0) {
            if (nbrMauvaiseLettre <= 9) {
                $('#dessin').attr('src', `images/bonhomme_pendu_${nbrMauvaiseLettre}.jpg`);
                $('#score').text(`Point possible : ${9 - nbrMauvaiseLettre} / 9`)
                mauvaisLettre();
                console.log('nbrMauvaiseLettre : ' + nbrMauvaiseLettre);

            }
            if (nbrMauvaiseLettre == 9) {
                fin(false);
                defeat();

            }
        } else {
            for (let i = 0; i < index.length; i++) {
                if (motCompleter() != true) {
                    $(`#underScore_index_${index[i]}`).attr('src', `images/lettres_mot/${lettre}.gif`);
                    bonneLettre();
                } else {
                    fin(true);
                    victory();
                }

            }
        }
    }

    function fin(victoire) {
        desactiverClavier();
        for (let i = VALEUR_ASKI_A; i <= VALEUR_ASKI_Z; i++) {
            let lettres = String.fromCharCode(i);
            let indexLet = verifierLettre(lettres);
            for (let j = 0; j <= indexLet.length; j++) {
                if (victoire == false) {
                    $(`#underScore_index_${indexLet[j]}`).attr('src', `images/lettres_rouge/${lettres}.gif`);
                } else {

                    $(`#underScore_index_${indexLet[j]}`).attr('src', `images/lettres_verte/${lettres}.gif`);
                }
            }


        }

        nextGame();


    }

    function desactiverClavier(){
        for (let i = VALEUR_ASKI_A; i <= VALEUR_ASKI_Z; i++) {
            let lettres = String.fromCharCode(i);
            $(`#${lettres}`).off('click');

    }}

    // Fonction pour créer des éléments HTML
    function createHtmlElement(tag, id) {
        return $('<' + tag + '></' + tag + '>').attr('id', id);
    }

    // Fonction pour créer des éléments d'image
    function createImage(id, path, width, height, alt) {
        return $('<img>').attr({
            id: id,
            src: path,
            width: width,
            height: height,
            alt: alt
        });
    }


    function nextGame() {
        miseAJour();
        setTimeout(reinitialiserValeur, 5000);
        setTimeout(newGamePlus, 5000);

    }

    function miseAJour() {

        $('#score').text(`Point possible : ${9} / 9`);
        $('#infoScore').text(`Vous avez pris ${min} minute${accord(min)} et ${sec} seconde${accord(sec)} pour decouvrir 0 mots sur 0 essai , ce qui vous a donné ${nbPointAccumuler()} point${accord(nbPointAccumuler())} `)


    }

});
